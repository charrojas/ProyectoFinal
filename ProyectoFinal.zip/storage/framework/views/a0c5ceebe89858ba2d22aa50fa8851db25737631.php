



<?php $__env->startSection('contenido'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <h1>Agregar imagenes al vehiculo</h1>

    <form action="<?php echo e(route('imagenes.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id_vehiculo" value="<?php echo e($vehiculo->id_vehiculo); ?>">
        <input type="file" name="imagen" class="custom-file-input form-control my-3">
        <button class="btn btn-lg btn-success float-end">Subir imagen</button>

    </form>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charr\Documents\Lenguajes\ProyectoFinal\resources\views/imagenes/create.blade.php ENDPATH**/ ?>