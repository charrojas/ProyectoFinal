
<link rel="stylesheet" href="../assets/css/templatemo.css">
<?php $__env->startSection('contenidoSlider'); ?>
    <div class="row" id="carousel">
        <div class="owl-carousel owl-theme">

            <div class="slide slide-1"></div>

            <div class="slide slide-2"></div>

            <div class="slide slide-3"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
    <div class="container"></div>
    
    <h3 style="color: blue" class="mb-4">¿Qué deseas hacer?</h3>s
    <div class="row">

        <div class="col-12 d-flex justify-content-center">
            <a href="<?php echo e(route('vehiculos.index')); ?>">
                <img src="./img/carss.png" class="img-fluid border" style="width: 50%;margin-left: -60%;"></a>
        </div>
        <div class="col-12 d-flex justify-content-center">
            <a href="<?php echo e(route('createCustom.vehiculos')); ?>">
                <img src="./img/1.png" class="img-fluid border"
                    style=" width: 50%;
                margin-left: 50%; margin-top: -42%;"></a>
        </div>

    </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charr\Documents\Lenguajes\ProyectoFinal\resources\views/paginas/index.blade.php ENDPATH**/ ?>