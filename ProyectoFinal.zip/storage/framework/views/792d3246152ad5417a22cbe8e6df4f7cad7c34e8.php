


<?php $__env->startSection('contenido'); ?>
    <form action="<?php echo e(route('storeCustom.vehiculos')); ?>" method="POST">

        <?php echo csrf_field(); ?>

        <div class="container px-3 py-3">
            <div class="row">

                <h2 class="text-center"> Registra tu vehiculo</h2>

                <div class="col-sm-6">

                    <div clas="form-group mb-3 mt-3">
                        <label for="marca">Marca</label>
                        <select class="form-control shadow" name="marca">
                            <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="text-center" value="<?php echo e($marca->id_marca); ?>"><?php echo e($marca->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group mb-3 mt-3">
                        <label for="modelo">Modelo</label>
                        <input type="text" class="form-control shadow" id="modelo" placeholder="Ingrese el modelo"
                            name="modelo">
                    </div>

                    <div class="form-group mb-3 mt-3">
                        <label for="estilo">Estilo</label>
                        <select class="form-control shadow" name="estilo">
                            <?php $__currentLoopData = $estilos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estilo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="text-center" value="<?php echo e($estilo->id_estilo); ?>"><?php echo e($estilo->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group mb-3 mt-3">
                        <label for="color_exterior">Color Exterior</label>
                        <select class="form-control shadow" name="color_exterior">
                            <?php $__currentLoopData = $color_exterior; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color_e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="text-center" value="<?php echo e($color_e->id_color_exterior); ?>"><?php echo e($color_e->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group mb-3 mt-3">
                        <label for="color_interior">Color Interior</label>
                        <select class="form-control shadow" name="color_interior">
                            <?php $__currentLoopData = $color_interior; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color_i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="text-center" value="<?php echo e($color_i->id_color_interior); ?>"><?php echo e($color_i->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group mb-3 mt-3">
                        <label for="transmision">Transmisión</label>
                        <input type="text" class="form-control shadow" id="transmision"
                            placeholder="Ingrese la transmisión" name="transmision">
                    </div>

                    <div class="form-group mb-3 mt-3">
                        <label for="cilindraje">Cilindraje</label>
                        <input type="text" class="form-control shadow" id="cilindraje"
                            placeholder="Ingrese el cilindraje" name="cilindraje">
                    </div>
                </div>

                <div class="col-sm-6">

                    <div class="form-group mb-3 mt-3">
                        <label for="combustible">Combustible</label>
                        <input type="text" class="form-control shadow" name="combustible"
                            placeholder="Ingrese el tipo de combustible">
                    </div>
                    <div class="form-group mb-3 mt-3"> <label for="recibe">Se recibe</label> <select
                            class="form-control shadow" name="recibe">
                            <option class="text-center" value="1">Sí</option>
                            <option class="text-center" value="0" selected>No</option>
                        </select>
                    </div>

                    <div class="form-group mb-3 mt-3"> <label for="cantidad_puertas">Cantidad de Puertas</label>
                        <input type="text" class="form-control shadow" id="cantidad_puertas"
                            placeholder="Ingrese el numero de puertas" name="cantidad_puertas">
                    </div>
                    <div class="form-group mb-3 mt-3"> <label for="anio">Año</label>
                        <input type="text" class="form-control shadow" id="anio"
                            placeholder="Ingrese el año del vehiculo" name="año">
                    </div>

                    <div class="form-group mb-3 mt-3"> <label for="precio">Precio</label>
                        <input type="text" class="form-control shadow" id="precio"
                            placeholder="Ingrese el precio del vehiculo" name="precio">
                    </div>

                    <br>
                    <br>
                    <button type="submit" class="btn btn-success btn-lg float-end shadow mt-4">Registrar</button>
                </div>
            </div>
        </div>
        </div>
        </div>
    </form>

    <form action="<?php echo e(route('imagenes.store')); ?>" method="POST" enctype="multipart/form-data">

        <p> Ha llenado correctamente los datos de su vehiculo.
            A continuacion suba las imagenes de su vehiculo para que los
            compadores las puedan visualizar.
        </p>

        <?php echo csrf_field(); ?>
        <input type="hidden" name="id_vehiculo" value="<?php echo e($vehiculo->id_vehiculo); ?>">
        <input type="file" name="imagen" class="custom-file-input">
        <button class="btn btn-primary">Subir</button>

    </form>

    <div class="imagenes" style="">
        <div class="row">

            <?php $__currentLoopData = $imagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 mt-4">
                    <div class="contenedor_img" style="position: relative">
                        <img src="<?php echo e(asset('uploads/' . $i->imagen)); ?>" alt=""
                            style="width: 100%; height: 100px;">
                        <form action="#" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger btn_eliminar_img"
                                style="position: absolute; top: 0; right: 0; border-radius: 50%">X</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charr\Documents\Lenguajes\ProyectoFinal\resources\views/vehiculos/edit.blade.php ENDPATH**/ ?>