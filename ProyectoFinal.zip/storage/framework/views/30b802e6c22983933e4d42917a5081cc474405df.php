

<link rel="stylesheet" href="<?php echo e(asset('/css/stylePerfil.css')); ?>">

<?php $__env->startSection('contenido'); ?>
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col col-lg-6 mb-4 mb-lg-0">
                <div class="card mb-3" style="border-radius: .5rem;">
                    <div class="row g-0">
                        <div class="col-md-4 gradient-custom text-center text-white"
                            style="border-top-left-radius: .5rem; border-bottom-left-radius: .5rem;">
                            <img src="<?php echo e(Auth::user()->avatar); ?>" alt="Avatar" class="img-fluid my-5 rounded-circle"
                                style="width: 120px;" />

                            <h5><?php echo e(Auth::user()->name); ?></h5>
                        </div>
                        <div class="col-md-8">
                            <div class="card-body p-4">
                                <h6>Información</h6>
                                <hr class="mt-0 mb-4">
                                <div class="row pt-1">
                                    <div class="col-6 mb-3">
                                        <h6>Email</h6>
                                        <p class="text-muted"><?php echo e(Auth::user()->email); ?></p>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <h6>Teléfono</h6>
                                        <p class="text-muted"> <?php echo e(Auth::user()->telefono); ?></p>
                                    </div>
                                </div>
                                <hr class="mt-0 mb-4">
                                <div class="row pt-1">
                                    <div class="col-6 mb-3">
                                        <h6>Dirección</h6>
                                        <p class="text-muted">Lorem ipsum</p>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <div>
                                            <a href="#!"><i class="fas fa-edit fa-lg me-3"></i></a>


                                        </div>
                                        <div>
                                            <a href="#!"><i class="fas fa-trash fa-lg me-3"></i></a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


</html>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charr\Documents\Lenguajes\ProyectoFinal\resources\views/usuario/perfil.blade.php ENDPATH**/ ?>