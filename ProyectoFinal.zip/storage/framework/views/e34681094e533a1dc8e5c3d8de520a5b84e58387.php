

<?php $__env->startSection('contenido'); ?>
    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="height: 200px; width: 200px">
            <img src="<?php echo e($img->imagen_url); ?>" alt="img">
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charr\Documents\Lenguajes\ProyectoFinal\resources\views/imagenes/index.blade.php ENDPATH**/ ?>