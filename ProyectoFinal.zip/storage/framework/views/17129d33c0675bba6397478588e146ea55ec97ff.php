
<?php /**PATH C:\Users\charr\Documents\Lenguajes\ProyectoFinal\resources\views/emails/welcome.blade.php ENDPATH**/ ?>