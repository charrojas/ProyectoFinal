@extends('app')



@section('contenido')
    @if (session('message'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('message') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    <h1>Agregar imagenes al vehiculo</h1>

    <form action="{{ route('imagenes.store')}}" method="POST" enctype="multipart/form-data">
        @csrf
        <input type="hidden" name="id_vehiculo" value="{{ $vehiculo->id_vehiculo }}">
        <input type="file" name="imagen" class="custom-file-input form-control my-3">
        <button class="btn btn-lg btn-success float-end">Subir imagen</button>

    </form>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
@endsection
