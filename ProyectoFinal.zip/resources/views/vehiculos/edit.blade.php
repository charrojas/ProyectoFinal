@extends('app')


@section('contenido')
    
    
    <div class="imagenes" style="">
        <div class="row">

            @foreach ($imagen as $i)
                <div class="col-sm-4 mt-4">
                    <div class="contenedor_img" style="position: relative">
                        <img src="{{ asset('uploads/' . $i->imagen) }}" alt=""
                            style="width: 100%; height: 100px;">
                        <form action="#" method="POST">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-danger btn_eliminar_img"
                                style="position: absolute; top: 0; right: 0; border-radius: 50%">X</button>
                        </form>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
