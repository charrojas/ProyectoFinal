<?php

namespace App\Http\Controllers;

use App\Models\ColorExterior;
use App\Models\ColorInterior;
use App\Models\Estilo;
use App\Models\Imagen;
use App\Models\Marca;
use App\Models\Modelo;
use App\Models\User;
use App\Models\Vehiculo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ControllerVehiculo extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $vehiculos = Vehiculo::all();
        $marcas = Marca::all();

        return view('vehiculos.index', compact('marcas', 'vehiculos'));
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $vehiculo = Vehiculo::with('usuario')->find($id);

        return view('vehiculos.show', compact('vehiculo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $vehiculo = Vehiculo::find($id);

        $imagen = Imagen::all();
        $imagen = Imagen::where('id_vehiculo', '=', $vehiculo->id_vehiculo);

        return view('vehiculos.edit', compact('vehiculo', 'imagen'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $vehiculo = Vehiculo::find($id);

        $imagen = new Imagen();

        $imagen->id_vehiculo = $vehiculo->id_vehiculo;
        $imagen->imagen = $request->imagen;

        $imagen->save();

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    //Funciones para las rutas excluidas por midleware
    public function createCustom()
    {

        $marcas = Marca::all();
        $estilos = Estilo::all();
        $color_exterior = ColorExterior::all();
        $color_interior = ColorInterior::all();
        $transmision = ColorInterior::all();
        $user = User::all();

        return view('vehiculos.create', compact('marcas', 'estilos', 'color_exterior', 'color_interior', 'user'));
    }

    public function storeCustom(Request $request)
    {

        $marcas = Marca::all();
        $estilos = Estilo::all();
        $color_exterior = ColorExterior::all();
        $color_interior = ColorInterior::all();
        $imagen = Imagen::get();

        $user = Auth::user();

        $vehiculo = new Vehiculo();
        $vehiculo->id_usuario = $user->id;
        $vehiculo->id_marca = $request->input('marca');
        $vehiculo->modelo = $request->modelo;
        $vehiculo->id_estilo = $request->input('estilo');
        $vehiculo->id_color_exterior = $request->input('color_exterior');
        $vehiculo->id_color_interior = $request->input('color_interior');
        $vehiculo->transmision = $request->transmision;
        $vehiculo->cilindraje = $request->cilindraje;
        $vehiculo->combustible = $request->combustible;
        $vehiculo->recibe = intval($request->recibe);
        $vehiculo->cantidad_puertas = $request->cantidad_puertas;
        $vehiculo->año = $request->año;
        $vehiculo->precio = $request->precio;

        $vehiculo->save();

        return view('imagenes.create', compact('vehiculo'))
        ->with('message', 'Vehículo registrado exitosamente. Por favor suba las imagenes de su vehiculo a continuacion.');;


    }

    //Subir imgs desde una carpeta de la PC
    public function fileUpload(Request $req)
    {
        $vehiculo_id = $req->input('id_vehiculo');
        $req->validate([
            'image' => 'required|mimes:jpg,png,jpeg|max:2048'
        ]);
        //dd($req);
        $imagenModel = new Imagen();
        if ($req->file('imagen')) {
            $imagenFile = $req->file('image');
            $imageName = time() . '_' . $req->file('image')->getClientOriginalName();
            $req->file('imagen')->move(public_path('uploads'), $imageName);

            $imagenModel = new Imagen();
            $imagenModel->imagen = $imageName;
            $imagenModel->id_vehiculo = $vehiculo_id;
            $imagenModel->save();
            //return $imagenModel;

            return back()
                ->with('success', 'La imagen ha sido subida correctamente.')
                ->with('file', $imageName);
        } else {
            return back()
                ->with('error', 'Error al subir la imagen.');
        }
    }
}
