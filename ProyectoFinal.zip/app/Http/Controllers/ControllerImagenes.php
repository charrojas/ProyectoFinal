<?php

namespace App\Http\Controllers;

use App\Models\Imagen;
use App\Models\Vehiculo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ControllerImagenes extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $imagenes = Imagen::all();

        return view('imagenes.index', compact('imagenes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'imagen' => 'required|image|mimes:jpg,jpeg,png',
            'id_vehiculo' => 'required|integer', // Agrega validación para el ID del vehículo
        ]);

        // Obtener el archivo cargado
        $imagen = $request->file('imagen');

        // Definir la ruta de destino en la carpeta public
        $ruta = public_path('uploads');

        // Generar un nombre único para el archivo
        $nombreArchivo = time() . '_' . $imagen->getClientOriginalName();

        // Mover el archivo a la carpeta de destino
        $imagen->move($ruta, $nombreArchivo);


        // Crea una nueva imagen en la base de datos y asigna el ID del vehículo
        $imagenModel = new Imagen();
        $imagenModel->id_vehiculo = $request->input('id_vehiculo');
        $imagenModel->imagen_url = '/uploads/' . $nombreArchivo; // Ruta relativa a la carpeta 'public'
        $imagenModel->save();

        $imagenes = Imagen::where('id_vehiculo', $request->input('id_vehiculo'))->get();

        return redirect()->route('imagenes.create', $request->input('id_vehiculo'))->with(compact('imagenes'))->with('success', 'Imagen subida exitosamente.');
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $imagen = Imagen::find($id);

        $imagen->delete();

        return redirect()->back();
    }
}
