<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class DatosController extends Controller
{
    public function guardarInformacion(Request $request)

    {
        // Obtiene los datos del formulario
        $telefono = $request->input('telefono');
        $direccion = $request->input('direccion');
        $providerId = $request->input('provider_id');

        // Encuentra el usuario correspondiente al identificador de usuario del proveedor
        $user = User::where('provider_id', $providerId)->first();

        if ($user) {
            // Actualiza la información del usuario
            $user->telefono = $telefono;
            $user->direccion = $direccion;
            $user->save();

            // Redirecciona o muestra un mensaje de éxito
            return redirect('paginas.index')->with('success', 'Información guardada exitosamente.');
        } else {
            // El usuario no existe, puedes mostrar un mensaje de error o realizar otras acciones según tu lógica
            return redirect('/login')->with('error', 'Usuario no encontrado.');
        }
    }
}
