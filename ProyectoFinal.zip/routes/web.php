<?php

use App\Http\Controllers\Auth\ControllerGoogle;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\ControllerLogin;
use App\Http\Controllers\ControllerPagina;
use App\Http\Controllers\ControllerVehiculo;
use App\Http\Controllers\ControllerImagenes;
use App\Http\Controllers\ControllerPerfil;
use App\Http\Controllers\DatosController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Laravel\Socialite\Facades\Socialite;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('app');
// });

//Ruta para ir a la pagina de contacto
Route::get('/contacto', function () {
    return view('contacto');
})->name('contacto');

Route::resource('/paginas', ControllerPagina::class);

Route::resource('/imagenes', ControllerImagenes::class)->middleware('auth');

Route::resource('/vehiculos', ControllerVehiculo::class)->except(['createCustom', 'storeCustom']);

Route::post('/upload', [ControllerVehiculo::class, 'fileUpload'])->name('upload');

Route::get('/vehiculos/create', [ControllerVehiculo::class, 'createCustom'])->name('createCustom.vehiculos')->middleware('auth');

Route::post('/vehiculos', [ControllerVehiculo::class, 'storeCustom'])->name('storeCustom.vehiculos')->middleware('auth');

Route::get('/', function () {
    return view('paginas.index');})->name('inicio'); //RUTA PARA DESPUÉS DE INICIAR SESIÓN NORMALITA

Auth::routes();

// Google login
Route::get('login/{driver}', [LoginController::class, 'redirectToProvider'])->name('login.provider');
Route::get('login/{driver}/callback', [LoginController::class, 'handleProviderCallback']);
// Ruta de cierre de sesión

Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
// Route::get('/register-create', [RegisterController::class, 'create'])->name('register-create');

Route::post('/registro', [RegisterController::class, 'create'])->name('registro.create');

// Route::post('/holi', [LoginController::class, 'dataExtra2'])->name('holi.dataExtra2');

Route::post('/guardar-informacion', [DatosController::class, 'guardarInformacion'])->name('guardar.informacion');



Route::get('/perfil', [ControllerPerfil::class, 'index'])->name('perfil');
